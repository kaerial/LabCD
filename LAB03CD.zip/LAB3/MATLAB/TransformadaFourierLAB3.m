% Parámetros
fs = 1000;            % Frecuencia de muestreo (Hz)
f = 10;               % Frecuencia de la onda cuadrada
t = 0:1/fs:1-1/fs;    % Tiempo
m = square(2*pi*f*t); % Señal modulante binaria

% FFT
N = length(m);
M = abs(fft(m));
f_axis = fs*(0:(N/2))/N;

% Mostrar solo mitad (simétrica)
M_half = M(1:N/2+1);

% Gráfica
figure;
plot(f_axis, M_half);
title('Transformada de Fourier de m(t) (onda cuadrada)');
xlabel('Frecuencia (Hz)');
ylabel('|M(f)|');
grid on;
