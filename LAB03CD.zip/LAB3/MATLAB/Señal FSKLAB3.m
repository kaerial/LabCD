% Parámetros
fs = 10000;         % Frecuencia de muestreo
bit_rate = 50;      % Tasa de bits
Tb = 1/bit_rate;    % Duración de un bit
Nbits = 10;         % Número de bits
t = 0:1/fs:Nbits*Tb-1/fs;  % Vector de tiempo

% Generar una secuencia binaria aleatoria
bits = randi([0 1], 1, Nbits);
bit_signal = repelem(bits, fs*Tb);

% Frecuencias para FSK
f0 = 1000;  % Frecuencia para bit 0
f1 = 2000;  % Frecuencia para bit 1

% Generar la señal FSK
fsk_signal = cos(2*pi*f0*t) .* (bit_signal == 0) + cos(2*pi*f1*t) .* (bit_signal == 1);

% FFT
N = length(fsk_signal);
f_axis = linspace(0, fs/2, N/2);
M = abs(fft(fsk_signal));
M = M(1:N/2);

% Graficar
figure;
plot(f_axis, M);
title('Espectro de la señal FSK');
xlabel('Frecuencia (Hz)');
ylabel('|FFT|');
grid on;
